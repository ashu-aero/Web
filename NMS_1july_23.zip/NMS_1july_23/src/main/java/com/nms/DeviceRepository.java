package com.nms;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface DeviceRepository extends JpaRepository<Device, Long>{
			
	@Query("SELECT u FROM Device u WHERE u.ip_address = ?1")
	public Device findByIp(String ip_address);
}

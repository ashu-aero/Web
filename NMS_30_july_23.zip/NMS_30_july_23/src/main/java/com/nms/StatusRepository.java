package com.nms;

import java.util.ArrayList;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface StatusRepository extends JpaRepository<Status, Long>{
	
	@Query("SELECT u FROM Status u WHERE u.ip_address = ?1")
	public ArrayList<Status> findAllRecordsByip(String ip_address);
	 
	@Query("SELECT u FROM Status u WHERE u.ip_address = ?1 and u.utimestamp is null")
	public Status findByIpWhoseisDown(String ip_address);	
	
	@Query("SELECT distinct u.ip_address FROM Status u ")
	public ArrayList<String> findAllIp();
	
}

package com.nms;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.data.repository.query.QueryLookupStrategy.Key;
import org.springframework.data.repository.support.Repositories;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@Controller
public class AppController {

	@Autowired
	private UserRepository userRepo;

	@Autowired
	private DeviceRepository deviceRepo;

	 
 

	@GetMapping("/home")
	public String homeScreen(Model model, HttpSession session) {
		boolean reachable = false;
		if (session.getAttribute("username") != null) {
			List<Device> deviceList = deviceRepo.findAll();
			 

			model.addAttribute("deviceList", deviceList);
			return "home";
		} else {
			return "redirect:/";
		}

	}

	@GetMapping("/device_list")
	public String deviceList(Model model, HttpSession session) {
		if (session.getAttribute("username") != null && session.getAttribute("username").toString().equals("admin")) {
			List<Device> deviceList = deviceRepo.findAll();
			model.addAttribute("deviceList", deviceList);
			return "deviceList";
		} else {
			return "redirect:/";
		}
	}

	@GetMapping("/device_delete")
	public String deviceDelete(Model model, HttpSession session, @Param("id") String id) {

		if (session.getAttribute("username") != null && session.getAttribute("username").toString().equals("admin")) {

			deviceRepo.deleteById(Long.parseLong(id));

			List<Device> deviceList = deviceRepo.findAll();
			model.addAttribute("deviceList", deviceList);
			return "deviceList";
		} else {
			return "redirect:/";
		}
	}

	@GetMapping("/device_edit")
	public String deviceEdit(Model model, HttpSession session, @Param("id") String id) {

		if (session.getAttribute("username") != null && session.getAttribute("username").toString().equals("admin")) {

			Device device = deviceRepo.getOne(Long.parseLong(id));

			List<Device> deviceList = deviceRepo.findAll();
			model.addAttribute("device", device);
			return "edit_device";
		} else {
			return "redirect:/";
		}
	}

	@GetMapping("/update_device")
	public String updateRegister(Device device, ModelMap modelMap, Model model, HttpSession session) {

		if (session.getAttribute("username") != null && session.getAttribute("username").toString().equals("admin")) {
			
			
			if(device.getIp_address()!=null && device.getIp_address().length()>0) {
				Device d=deviceRepo.findByIp(device.getIp_address());
				if(d==null) {
					deviceRepo.save(device);
					modelMap.addAttribute("msg", "Device updated Successfully.");
				}
				else {
					modelMap.addAttribute("msg", "This IP address is already added.");
				}
			}
			
			 

			List<Device> deviceList = deviceRepo.findAll();
			model.addAttribute("deviceList", deviceList);
			return "deviceList";
		} else {
			return "redirect:/";
		}

	}

	@GetMapping("/add_device")
	public String addIp(HttpSession session) {

		if (session.getAttribute("username") != null) {
			return "add_device";
		} else {
			return "redirect:/";
		}

	}

	 

	@RequestMapping(value="/add_device" , method=RequestMethod.POST)
	public String deviceRegister(Device device, ModelMap modelMap, HttpSession session) {

		if (session.getAttribute("username") != null) {
			device.setStatus(false);
			
			if(device.getIp_address()!=null && device.getIp_address().length()>0) {
				Device d=deviceRepo.findByIp(device.getIp_address());
				if(d==null) {
					deviceRepo.save(device);
					modelMap.addAttribute("msg", "Device added Successfully.");
				}
				else {
					modelMap.addAttribute("msg", "This IP address is already added.");
				}
			}
			

			return "add_device";
		} else {
			return "redirect:/";
		}

	}

	
	
	
	
	

	@RequestMapping(value = "/test_json_api", produces = "application/json", method = RequestMethod.GET)
	@ResponseBody
	public Map<Integer, Device> test_json_api() {
		List<Device> deviceList = deviceRepo.findAll();
		Map<Integer, Device> deviceMap = new HashMap<>();
		for (int i = 0; i < deviceList.size(); i++) {
			deviceMap.put((i + 1), deviceList.get(i));
		}

		return deviceMap;
	}
	
	
    
}

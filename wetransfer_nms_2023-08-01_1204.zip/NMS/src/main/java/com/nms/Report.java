package com.nms;

public class Report {
	private String location;
	private String serviceProvider;
	private String ip;
	private String downTime;
	private String upTime;
	private String totalDownTime;
	/**
	 * @return the location
	 */
	public String getLocation() {
		return location;
	}
	/**
	 * @param location the location to set
	 */
	public void setLocation(String location) {
		this.location = location;
	}
	/**
	 * @return the serviceProvider
	 */
	public String getServiceProvider() {
		return serviceProvider;
	}
	/**
	 * @param serviceProvider the serviceProvider to set
	 */
	public void setServiceProvider(String serviceProvider) {
		this.serviceProvider = serviceProvider;
	}
	/**
	 * @return the ip
	 */
	public String getIp() {
		return ip;
	}
	/**
	 * @param ip the ip to set
	 */
	public void setIp(String ip) {
		this.ip = ip;
	}
	/**
	 * @return the downTime
	 */
	public String getDownTime() {
		return downTime;
	}
	/**
	 * @param downTime the downTime to set
	 */
	public void setDownTime(String downTime) {
		this.downTime = downTime;
	}
	/**
	 * @return the upTime
	 */
	public String getUpTime() {
		return upTime;
	}
	/**
	 * @param upTime the upTime to set
	 */
	public void setUpTime(String upTime) {
		this.upTime = upTime;
	}
	/**
	 * @return the totalDownTime
	 */
	public String getTotalDownTime() {
		return totalDownTime;
	}
	/**
	 * @param totalDownTime the totalDownTime to set
	 */
	public void setTotalDownTime(String totalDownTime) {
		this.totalDownTime = totalDownTime;
	}

}

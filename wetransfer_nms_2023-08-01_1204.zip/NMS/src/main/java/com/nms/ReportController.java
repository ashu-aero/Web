package com.nms;

import java.net.InetAddress;
import java.sql.Timestamp;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.poi.util.SystemOutLogger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.data.repository.query.QueryLookupStrategy.Key;
import org.springframework.data.repository.support.Repositories;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import ch.qos.logback.core.net.SyslogOutputStream;

@Controller
public class ReportController {

	@Autowired
	private DeviceRepository deviceRepo;
	
	@Autowired
	private StatusRepository statusRepo;
	
	@Autowired
	private ExcelReport excelReport;

	 
 
	@GetMapping("report")
	public String statusReport(Model model, 
			ModelMap modelMap, 
			HttpSession session, 
			@Param("ip_adrs") String ip_adrs ,  
			@Param("date") String date){
		if (session.getAttribute("username") != null && session.getAttribute("username").toString().equals("admin")){
			ArrayList<String> arrayListIp=statusRepo.findAllIp();
			model.addAttribute("arrayListIp", arrayListIp);
			model.addAttribute("ip_adrs", ip_adrs);
			
			ArrayList<String> arrayListdate=statusRepo.findAlldtimestamp();
			model.addAttribute("arrayListdate", arrayListdate);
			model.addAttribute("date", date);
			 
			ArrayList<Status> statusList=new ArrayList<>();
			
			
			
			
			
			if(ip_adrs!=null && ip_adrs.length()>0) {
				statusList=(ArrayList<Status>)statusRepo.findAllRecordsByip(ip_adrs);
			}
			else {
				statusList=(ArrayList<Status>)statusRepo.findAll();
			}
			
			
			
			
			
			
		 
			ArrayList<Report> arrayListReport=new ArrayList<>();		
			for(int i=0; i<statusList.size();i++) {
				Report report=new Report();
				Status status=statusList.get(i);				
				String ip=status.getIp_address();
				Device device= deviceRepo.findByIp(ip);				
				report.setLocation(device.getLocation());
				report.setServiceProvider(device.getNetwork_provider());
				report.setIp(ip);
				report.setDownTime(""+status.getDtimestamp());
				report.setUpTime(""+status.getUtimestamp());
								
				Timestamp upTime=null;
	        	if(status.getUtimestamp()!=null){
	        		   upTime=status.getUtimestamp();
	        	}
	        	Timestamp downTime=null;
	        	if(status.getDtimestamp()!=null){
	        		downTime=status.getDtimestamp();
	        	}
	        	   
	        	String timeInHHMMSS ="";
	        	   
	        	if(status.getUtimestamp()!=null && status.getDtimestamp()!=null){
	        	   long totalDownTime = upTime.getTime() - downTime.getTime();       		   
	        	   Duration duration = Duration.ofMillis(totalDownTime);        		   
	        	   long HH = duration.toHours();
	        	   long MM = duration.toMinutesPart();
	        	   long SS = duration.toSecondsPart();
	        	   timeInHHMMSS = String.format("%02d:%02d:%02d", HH, MM, SS);
	        	}							
				report.setTotalDownTime(timeInHHMMSS);				
				arrayListReport.add(report);				
			}
			
			model.addAttribute("arrayListReport", arrayListReport);			
			
			
			
			//System.out.println("arrayListIp size: "+arrayListIp.size());
			
			
			
			
			
			return "report";
		}
		else {
			return "redrect:/";
		}
	}
	 
	

	@GetMapping("/excel")	
	public void generateExcelReport(HttpServletResponse response,
			Model model, 
			ModelMap modelMap, 
			HttpSession session, 
			@Param("ip_adrs") String ip_adrs ,  
			@Param("date") String date) throws Exception{
		
		if (session.getAttribute("username") != null && session.getAttribute("username").toString().equals("admin")){
		response.setContentType("application/octet-stream");
		
		String headerKey = "Content-Disposition";
		String headerValue = "attachment;filename=status.xls";

		response.setHeader(headerKey, headerValue);
		
		
		
		
		
		
		
		ArrayList<String> arrayListIp=statusRepo.findAllIp();
		model.addAttribute("arrayListIp", arrayListIp);
		model.addAttribute("ip_adrs", ip_adrs);
		
		ArrayList<String> arrayListdate=statusRepo.findAlldtimestamp();
		model.addAttribute("arrayListdate", arrayListdate);
		model.addAttribute("date", date);
		 
		ArrayList<Status> statusList=new ArrayList<>();
		
		
		
		
		
		if(ip_adrs!=null && ip_adrs.length()>0) {
			statusList=(ArrayList<Status>)statusRepo.findAllRecordsByip(ip_adrs);
		}
		else {
			statusList=(ArrayList<Status>)statusRepo.findAll();
		}
		
		
		
		
		
		
	 
		ArrayList<Report> arrayListReport=new ArrayList<>();		
		for(int i=0; i<statusList.size();i++) {
			Report report=new Report();
			Status status=statusList.get(i);				
			String ip=status.getIp_address();
			Device device= deviceRepo.findByIp(ip);				
			report.setLocation(device.getLocation());
			report.setServiceProvider(device.getNetwork_provider());
			report.setIp(ip);
			report.setDownTime(""+status.getDtimestamp());
			report.setUpTime(""+status.getUtimestamp());
							
			Timestamp upTime=null;
        	if(status.getUtimestamp()!=null){
        		   upTime=status.getUtimestamp();
        	}
        	Timestamp downTime=null;
        	if(status.getDtimestamp()!=null){
        		downTime=status.getDtimestamp();
        	}
        	   
        	String timeInHHMMSS ="";
        	   
        	if(status.getUtimestamp()!=null && status.getDtimestamp()!=null){
        	   long totalDownTime = upTime.getTime() - downTime.getTime();       		   
        	   Duration duration = Duration.ofMillis(totalDownTime);        		   
        	   long HH = duration.toHours();
        	   long MM = duration.toMinutesPart();
        	   long SS = duration.toSecondsPart();
        	   timeInHHMMSS = String.format("%02d:%02d:%02d", HH, MM, SS);
        	}							
			report.setTotalDownTime(timeInHHMMSS);				
			arrayListReport.add(report);				
		}
		

				
		
		
		
		
		excelReport.generateExcel(response, arrayListReport);
		
		response.flushBuffer();
	}
	 
	}
    
}
